const mysql=require("mysql");
const express=require('express');
const app=express();
const http=require('http');
const path=require('path');
const dotenv=require('dotenv');
const { dirname } = require("path");
const { fail } = require("assert");
const { json } = require("body-parser");
const { stringify } = require("querystring");
const { response } = require("express");
var cryptr=require('cryptr');
cryptr=new cryptr('devnami');

const db=mysql.createPool({
    server: 'localhost',
     port:3306 ,
    user: 'root',
    password: 'Password1',
     database: 'abbreviations',
    options: {
       encrypt: false, // true for azure
       trustServerCertificate: true // change to true for local dev / self-signed certs
   }
   });
  
  exports.abbreviation=(req,res)=>{
     
    console.log(req.body);

    const {keyword,text} = req.body;
    
    //create request object
    db.getConnection((error,connection)=>{
        if(error){
          console.log(error);
        }
        else{
          if(keyword==""||text=="")
          {
            return res.render('index',{
              message:'Please enter the details!!'
           });
           
          }
          else
          {
          
                connection.query("SELECT keyword FROM abbreviations WHERE keyword = ?",[keyword],(error,results)=>{
                  if(error){
                    
                     console.log(error);
                   }
                    if(results.length>0){
                      connection.release();
                    return res.render('index',{
                        message:'That keyword already exists'
                    });
                   }
                  
                  else{
                     
                    connection.query("INSERT INTO abbreviations (keyword,Text1) VALUES(?, ?)", [keyword,text],(error,results)=>{
                      if(error){
                       console.log(error);
                     }else{     connection.release();
                                return res.render('index',{
                                message:'word included'
                             });
                          }
                        });

                  }
              });
                }  
      }
      
  });
}