const express=require('express');
const authController=require('../controllers/auth');
const mysql=require("mysql");
const { json } = require("body-parser");
const http=require('http');
const path=require('path');
const router=express.Router();

let db=mysql.createPool({
    server: 'localhost',
     port:3306 ,
    user: 'root',
    password: 'Password1',
     database: 'abbreviations',
    options: {
       encrypt: false, // true for azure
       trustServerCertificate: true // change to true for local dev / self-signed certs
   }
   });
  
router.post('/abbreviation',authController.abbreviation);

router.get('/explode',function(req,res,next){
    let search_query=req.query.search_query;
    console.log(req.query);
    console.log("SO");
    //var query="SELECT Text1 FROM abbreviations WHERE keyword LIKE ?",['%' + search_query + '%'];
        db.getConnection((error,connection)=>{
        if(error){
          console.log(error);
        }
        else{
            connection.query("SELECT Text1 FROM abbreviations WHERE keyword = ?",[search_query],function(error,results){
            console.log(results);
             res.json(results); 
             connection.release();  
            });
        }
    });    
});


module.exports=router;