const express=require('express');

const router=express.Router();

var session1;

router.get('/',(req,res)=>{
    res.render('index');
});

router.get('/explode',(req,res)=>{
    session1=req.session;
    if(session1.staffid)
    {
    res.render('explode');
    }
    else
    {
        res.render('index',{message:'Please login to view this page!'});
    }
});


router.get('/abbreviation',(req,res)=>{
    session1=req.session;
    if(session1.staffid)
    {
    res.render('abbreviation');
    }
    else
    {
        res.render('index',{message:'Please login to view the page!'});
    }
});


module.exports=router;