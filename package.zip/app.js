const express=require("express");
const session = require('express-session');
const path=require('path');
const mysql=require("mysql");
const app=express();
const dotenv=require('dotenv');
const { dirname } = require("path");
const { fail } = require("assert");
const { join } = require("path");
dotenv.config=({path:'./.env'});

let db=mysql.createConnection({
 server: 'localhost',
  port:3306 ,
 user: 'root',
 password: 'Password1',
  database: 'abbreviations',
 options: {
    encrypt: false, // true for azure
    trustServerCertificate: true // change to true for local dev / self-signed certs
}
});

const publicDirectory=path.join(__dirname,'./public');
app.use(express.static(publicDirectory));
console.log(__dirname);
app.set('view engine','hbs');

db.connect((error)=>{
  if(error){
    console.log(error)
  }
    else{
      console.log("Mysql connected...")
    }
 
})

app.use(
  session({
  secret: 'thisisasecret',
  saveUninitialized: true,
  resave: true
  })
  );

  //Parse URL-encoded bodies(as sent by HTML forms)
app.use(express.urlencoded({extended:false}));
//Parse json bodies(as sent by API clients)
app.use(express.json());

//Define routes
app.use('/',require('./routes/pages'));
app.use('/auth',require('./routes/auth'));

app.listen(5000,()=>{
  console.log("Server is running on port 5000");
})